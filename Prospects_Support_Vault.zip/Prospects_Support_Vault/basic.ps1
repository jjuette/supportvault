﻿cls
     write-host '                   ______      __              ___         __  
                  / ____/_  __/ /_  ___  _____/   |  _____/ /__Ã†
                 / /   / / / / __ \/ _ \/ ___/ /| | / ___/ //_/
                / /___/ /_/ / /_/ /  __/ /  / ___ |/ /  / ,<   
                \____/\___ /_____/\___/_/  /_/  |_/_/  /_/|_|  
                      ____/' -ForegroundColor green
write-host "#################################################################################"-ForegroundColor blue
write-host -nonewline -f blue "#";write-host -nonewline " Update Existing Prospects or Customer Locations in the Support Vault          ";write-host -f blue "#"
write-host -nonewline -f blue "#";write-host -nonewline " By Joe Juette                                                                 ";write-host -f blue "#"
write-host "#################################################################################"-ForegroundColor blue
write-host "#################################################################################"-ForegroundColor blue
#---get PACLI process 
$pacli = Get-Process pacli -ErrorAction SilentlyContinue;
#---Insure that PACLI is stopped
if ($pacli) 
{
  #---Shutdown
  & $PSScriptRoot\PACLI\pacli term
}
  ElseIf ($pacli) 
{ 
  #---kill
   Stop-Process -Name "pacli"
}
Remove-Variable pacli
#---Init PACLI
& $PSScriptRoot\PACLI\pacli init
#---Build PACLI Path to be used for commands
$pacliPath = $PSScriptRoot + '\PACLI\pacli'
#---User Inputs vars
 #---Define Vault Input Vars
 #---$usrVaultAdd = Read-Host "What is the Vault Address"#---Change to support.cyberark.com when using support vault only
 #---$usrVaultDef = Read-Host "What is the Defined Vault"
 #---Login to Support Vault
 Write-Host "Login to The Support Vault"
 $usrName = Read-host "Input Your Username: "
 $usrPasswd = Read-host "Input Your Password: " -AsSecureString
 $usrSecurePwd = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($usrPasswd))
#---Write-Host "$usrSecurePwd"
#---PACLI Routines 
 #---Define Vault
  #---Support Vault
    #---Variables
    #---$supVaultDef= "Support Vault"
    #---$supVaultAdd= "support.cyberark.com"
  #---Hard-Coded Vault Definition
  & $pacliPath DEFINE VAULT="""Vault""" ADDRESS="""10.0.1.10"""
  #---From Support Vault Variables
  #---& $pacliPath DEFINE VAULT="""$supVaultDef""" ADDRESS="""$supVaultAdd"""
  #---From User Input
  #---& $pacliPath DEFINE VAULT="""$usrVaultDef""" ADDRESS="""$usrVaultAdd"""
 #---Logon to Vault
  #---Login to Vault by User Vault Input
   #---& $pacliPath LOGON VAULT="""$usrVaultDef""" USER="""$usrName""" PASSWORD="""$usrSecurePwd"""
  #---Login to Vault Hard-Coded Vault Def
   & $pacliPath LOGON VAULT="""Vault""" USER="""$usrName""" PASSWORD="""$usrSecurePwd"""
 #---User Menu
 function MainMenu
{
     param (
           [string]$Title = 'Support Vault Functions'
     )
Write-Host "================ $Title ================"
Write-Host "1: Press '1' to Add a new user to Support Vault "
Write-Host "2: Press '2' to Update Existing Company Support Vault With a User"
Write-Host "3: Press '3' to List Locations"
Write-Host "4: Press '4' to reset Users Password"
Write-Host "Q: Press 'Q' To quit and Logoff."
}
do
{
 Mainmenu
 $input = Read-Host "Please make a selection"
 switch ($input)
     {
             '1' {
                 #---Adding New User to the Support Vault
                 $newUsrName = Read-Host "Enter New Username (Users Email Address)"
                  #---Generate a random password
                 $length = Read-Host "Enter The Desired Password Length"
                  #---Usage: random-password <length>
                  Function random-password ($length)
                  {
                  $punc = 46..46
                  $digits = 48..57
                  $letters = 65..90 + 97..122
                  $newUsrPasswd = get-random -count $length `
                    -input ($punc + $digits + $letters) |
                  % -begin { $aa = $null } `
                    -process {$aa += [char]$_} `
                    -end {$aa}
                    return $newUsrPasswd
                  }
                #Location stuff
                 
                 } 
             '3' {
               #---Enter Company Name
                  $newCompanyName = Read-Host "Enter The Company Name"
                  $newCompanyLocSearch = & $pacliPath LOCATIONSLIST VAULT="""Vault""" USER="""$usrName""" OUTPUT`(`NAME`) #---Change Vault to support vault var
                  #---Search For Existing Company
                  $patternFound = select-string -pattern "$newCompanyName" -InputObject $newCompanyLocSearch
                  if ($patternFound -ne $null)
                  {
                  Write-Host = "The Company Already Exists, You Must Update The Existing Company With The New User"
                  mainmenu
                  }
                  Else
                  {
                   #---Create New Location Based on Company Name

try {
    Set-Content .\ADDBat.bat "@echo off`n$pacliPath ADDLOCATION VAULT=""Vault"" USER=""$usrName"" LOCATION=""\Americas\Prospect Locations\$newCompanyName"""
    & .\ADDBat.bat
} catch {
    $error = $_.Exception.Message
    Write-Host "ERROR MESSAGE: $error"
} finally {
    rm ADDBat.bat
}  

                  
                 #--- Create New User
                 #  & $pacliPath ADDUSER VAULT="""Vault""" USER="""$usrName""" DESTUSER="""$newUsrName""" PASSWORD="""$newUsrPasswd""" 

                  }
                 }
                 #---Update Exiting Company Support Vault
             '2' {
                 #---Create Location List output names to Variable
                 $LocSearch = & $pacliPath LOCATIONSLIST VAULT="""Vault""" USER="""$usrName""" OUTPUT`(`NAME`) #---Change Vault to support vault var
                 Write-Host = "$LocSearch"
                 #---Get User Input of Company Name to update
                 $CompanyName = Read-Host "Which Company would you like to update"
                 #---Search Locations List Variable for Company Name

                 } 
             'q' {
                 #Logoff From Vault
                 #Disconnect-Vault  -vault """Vault""" -user """$usrName""" #---Change Vault to support vault var
                 #Stop Pacli process
                 #Stop-PACLI
                 }
      }
     pause
     
}
until ($input -eq 'q')