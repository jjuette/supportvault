cls
write-host '                   ______      __              ___         __  
                  / ____/_  __/ /_  ___  _____/   |  _____/ /__Æ
                 / /   / / / / __ \/ _ \/ ___/ /| | / ___/ //_/
                / /___/ /_/ / /_/ /  __/ /  / ___ |/ /  / ,<   
                \____/\___ /_____/\___/_/  /_/  |_/_/  /_/|_|  
                      ____/' -ForegroundColor green
write-host "#################################################################################"-ForegroundColor blue
write-host -nonewline -f blue "# ";write-host -nonewline "Super fun example of using the CyberArk RESTfull API with Powershell >= v3              ";write-host -f blue "#"
write-host -nonewline -f blue "# ";write-host -nonewline "CyberArk Software                                                             ";write-host -f blue "#"
write-host "#################################################################################"-ForegroundColor blue
write-host "#################################################################################"-ForegroundColor blue
pause
$Name = Read-Host "Input Username: "
$securepw = Read-host "Input Password: " -AsSecureString
$password = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($securepw))
$LogonResource = "https://components.brandonlab.local/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logon"
$LogoffResource = "https://components.brandonlab.local/PasswordVault/WebServices/auth/Cyberark/CyberArkAuthenticationService.svc/Logoff"
$SafeResource = "https://components.brandonlab.local/PasswordVault/WebServices/PIMServices.svc/Safes"
$AccountResource = "https://components.brandonlab.local/PasswordVault/WebServices/PIMServices.svc/Account"
$ApplicationResource = "https://components.brandonlab.local/PasswordVault/WebServices/PIMServices.svc/Applications/"
$PasswordBody = @{password="$password";username="$Name"}
$token=(Invoke-RestMethod -Method Post -Uri "$LogonResource" -Body (ConvertTo-Json $PasswordBody -compress) -ContentType application/json).CyberArkLogonResult
write-host "Your Token = $token"
#### Add Application

#Invoke-RestMethod -Method Post -Uri "$ApplicationResource" -Body '{"application":{"AppID":"RestApp", "Description":"Programatically created application using REST"}}' -ContentType application/json -Headers @{Authorization="$token"}

#### Destroy Application
#$AppID = Read-Host "Input AppID: "
#Invoke-RestMethod -Method Delete -Uri "$ApplicationResource/$AppID" -ContentType application/json -Headers @{Authorization="$token"}

####ListAuthentications

#$AppID = Read-Host "Input AppID: "
#Invoke-RestMethod -Method Get -Uri "$ApplicationResource/$AppID/Authentications" -ContentType application/json -Headers @{Authorization="$token"}

####DeleteAuthentication
#$AuthID = Read-Host "Input Authentication ID: "
#Invoke-RestMethod -Method Delete -Uri "$ApplicationResource/$AppID/Authentications/$AuthID" -ContentType application/json -Headers @{Authorization="$token"}

#### Logoff
#Invoke-RestMethod -Method Post -Uri "$LogoffResource" -ContentType application/json -Headers @{Authorization="$token"}

#### Add Safe
#Invoke-RestMethod -Method Post -Uri "$SafeResource" -Body '{"safe":{"SafeName":"SampleSafe", "Description": "Sample REST API Safe", "OLACEnabled": false, "ManagingCPM": "PasswordManager", "NumberOfDaysRetention":30}}' -ContentType application/json -Headers @{Authorization="$token"}

#### Add Account
Invoke-RestMethod -Method Post -Uri "$AccountResource" -Body '{"account":{"safe":"SampleSafe","platformID":"UnixSSH","address":"10.150.1.27","accountName":"TestUserObject12345","password": "Cyberark1","username": "testuser"}}' -ContentType application/json -Headers @{Authorization="$token"}

#### Get Account
#Invoke-RestMethod -Method Get -Uri "http://10.150.1.105/PasswordVault/WebServices/PIMServices.svc/Accounts?/keywords=root%2C10.150.1.111" -ContentType application/json -Headers @{Authorization="$token"}

#### Update Account





#### Delete Account

pause