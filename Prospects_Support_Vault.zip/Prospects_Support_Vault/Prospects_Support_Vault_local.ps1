cls
#Import PoShPACLI
Import-Module PoShPACLI
#locate/set path to PACLI executable
Initialize-PoShPACLI -pacliExe Pacli.exe -pacliFolder C:\Users\Mike\Desktop\Prospects_Support_Vault\PACLI

#Start PACLI Executable
Start-PACLI

#User Inputs vars
$usrVaultAdd = Read-Host "What is the Vault Address"
$usrVaultDef = Read-Host "What is the Defined Vault"
$usrName = Read-host "Input Username: "
$usrPasswd = Read-host "Input Password: " -AsSecureString
$usrSecurePwd = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($usrPasswd))

#Define Vault
Add-VaultDefinition -vault "$usrVaultDef" -address "$usrVaultAdd" -Debug -Verbose



function Show-Menu
{
     param (
           [string]$Title = 'Support Vault Functions'
     )
     write-host '                   ______      __              ___         __  
                  / ____/_  __/ /_  ___  _____/   |  _____/ /__Æ
                 / /   / / / / __ \/ _ \/ ___/ /| | / ___/ //_/
                / /___/ /_/ / /_/ /  __/ /  / ___ |/ /  / ,<   
                \____/\___ /_____/\___/_/  /_/  |_/_/  /_/|_|  
                      ____/' -ForegroundColor green
write-host "#################################################################################"-ForegroundColor blue
write-host -nonewline -f blue "#";write-host -nonewline " Update Existing Prospects or Customer Locations in the Support Vault          ";write-host -f blue "#"
write-host -nonewline -f blue "#";write-host -nonewline " CyberArk Software                                                             ";write-host -f blue "#"
write-host "#################################################################################"-ForegroundColor blue
write-host "#################################################################################"-ForegroundColor blue
     
Write-Host "================ $Title ================"
Write-Host "1: Press '1' to login to the Support Vault. (Required)"
Write-Host "2: Press '2' to logoff the Support Vault when finished."
Write-Host "3: Press '3' for this option."
Write-Host "Q: Press 'Q' To quit and Logoff."
}
do
{
 Show-Menu
 $input = Read-Host "Please make a selection"
 switch ($input)
     {
             '1' {
                 #--PACLI Login
    Connect-Vault -vault """$usrVaultDef""" -user """$usrName""" -password """$usrSecurePwd""" Write-Verbose Write-Debug

                 } 
             '2' {
                 Invoke-RestMethod -Method Post -Uri "$LogoffResource" -ContentType application/json -Headers @{Authorization="$token"}
                 clear-variable -Name "token"
                 write-host "You have been successfully logged off. Your Authorization Token has been cleared."
                 } 
             '3' {
                cls
                'You chose option #3'
                 } 
             'q' {
                 #Logoff From Vault
                 Disconnect-Vault  -vault "$usrVaultDef" -user "$usrName"
                 #Stop Pacli process
                 Stop-PACLI
                 }
      }
     pause
}
until ($input -eq 'q')




#### Add Application Rest Method

#Invoke-RestMethod -Method Post -Uri "$ApplicationResource" -Body '{"application":{"AppID":"RestApp", "Description":"Programatically created application using REST"}}' -ContentType application/json -Headers @{Authorization="$token"}

#### Destroy Application
#$AppID = Read-Host "Input AppID: "
#Invoke-RestMethod -Method Delete -Uri "$ApplicationResource/$AppID" -ContentType application/json -Headers @{Authorization="$token"}

####ListAuthentications

#$AppID = Read-Host "Input AppID: "
#Invoke-RestMethod -Method Get -Uri "$ApplicationResource/$AppID/Authentications" -ContentType application/json -Headers @{Authorization="$token"}

####DeleteAuthentication
#$AuthID = Read-Host "Input Authentication ID: "
#Invoke-RestMethod -Method Delete -Uri "$ApplicationResource/$AppID/Authentications/$AuthID" -ContentType application/json -Headers @{Authorization="$token"}

#### Logoff
#Invoke-RestMethod -Method Post -Uri "$LogoffResource" -ContentType application/json -Headers @{Authorization="$token"}

#### Add Safe
#Invoke-RestMethod -Method Post -Uri "$SafeResource" -Body '{"safe":{"SafeName":"SampleSafe", "Description": "Sample REST API Safe", "OLACEnabled": false, "ManagingCPM": "PasswordManager", "NumberOfDaysRetention":30}}' -ContentType application/json -Headers @{Authorization="$token"}

#### Add Account
#Invoke-RestMethod -Method Post -Uri "$AccountResource" -Body '{"account":{"safe":"SampleSafe","platformID":"UnixSSH","address":"10.150.1.27","accountName":"TestUserObject12345","password": "Cyberark1","username": "testuser"}}' -ContentType application/json -Headers @{Authorization="$token"}

#### Get Account
#Invoke-RestMethod -Method Get -Uri "http://10.150.1.105/PasswordVault/WebServices/PIMServices.svc/Accounts?/keywords=root%2C10.150.1.111" -ContentType application/json -Headers @{Authorization="$token"}

#### Update Account

#### Delete Account

#### 

####

pause