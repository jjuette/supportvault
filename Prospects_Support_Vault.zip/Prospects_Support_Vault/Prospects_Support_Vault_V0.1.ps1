﻿Import-Module pspacli
Set-PacliCleanup -pacliCleanup $false #---Use to troubleshoot action set to false to keep files set to true to delete them
Set-PacliPath $PSScriptRoot\PACLI\pacli.exe

#---Behind The Scenes
    #---Get PACLI Process
        $pacli = Get-Process pacli -ErrorAction SilentlyContinue;
    #---Insure that PACLI is stopped
        if ($pacli){
            #---Shutdown
                & $PSScriptRoot\PACLI\pacli term
        }
        ElseIf ($pacli){ 
            #---kill
                Stop-Process -Name "pacli"
        }
        Remove-Variable pacli
    #---Build PACLI Path to be used for commands based on powershell script location
        $pacliPath = $PSScriptRoot + '\PACLI\pacli'
    #---Init PACLI from where the script is being run from(The Pacli Directory must be in the same folder as this Script)
        Invoke-Pacli init
        #& $pacliPath init
    #---Intial PACLI Required Routines
        #---Define Vault
            #---Support Vault
                <#---Block Comment For Development Remove for Production
                $supVaultDef= "Support Vault"
                $supVaultAdd= "support.cyberark.com"
                try {
                    Set-Content .\DEFBat.bat "@echo off`n$pacliPath DEFINE VAULT=""$supVaultDef"" ADDRESS=""$supVaultAdd"""
                    & .\DEFBat.bat
                } 
                catch {
                    $error = $_.Exception.Message
                    Write-Host "ERROR MESSAGE: $error"
                }
                finally {
                    rm DEFBat.bat
                }
            #---End Support Vault Definition
                #>#---End Block Comment For Development Remove for Production
            #---Hard-Coded Vault Definition
                Invoke-Pacli DEFINE VAULT=`"VAULT`" ADDRESS=10.0.1.10
            #---End Hard-Coded Vault Definition
#---End Behind The Scenes
        
#---Logon to Vault
    #---Login to Support Vault
        <#---Block Comment For Development Remove for Production
        Write-Host "Login to The Support Vault"
        $usrName = Read-host "Input Your Username: "
        $usrPasswd = Read-host "Input Your Password: " -AsSecureString
        $usrSecurePwd = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($usrPasswd))
        try {
            Set-Content .\SupLogBat.bat "@echo off`n$pacliPath LOGON VAULT=""$supVaultDef"" USER=""$usrName"" PASSWORD=""$usrSecurePwd"""
            & .\SupLogBat.bat
        } 
        catch {
            $error = $_.Exception.Message
            Write-Host "ERROR MESSAGE: $error"
        }
        finally {
            rm SupLogBat.bat
        }
    #---End Login to Support Vault    
        #>#---End Block Comment For Development Remove for Production
#---Login to Vault Hard-Coded Vault Def
    #---Hard Coded Var Delete When Done
        $usrName="Administrator"
        Invoke-Pacli DEFAULT vault=`"Vault`" User=`"$usrName`" Folder=`"root`"
    #---Hard Coded Login For Development Remove for Production
        Invoke-Pacli LOGON PASSWORD=`"Cyberark1`"
#---Vault Operation Functions
    #---Build Location List
        Function LocationList{
		Invoke-Pacli LOCATIONSLIST OUTPUT`(NAME`) #---Change Vault to support vault var
        }
	#---End Build Location List
	#---Build User List
		Function UserList{
			Invoke-Pacli USERSLIST OUTPUT`(NAME`) #---Change Vault to support vault var
		}
	#---End Build User List
	#---Company Search Function
        Function CompanySearch{
			SearchLocation		
        }
    #---End Company Search Function
    #---User Search Function
		Function UserSearch{
			SearchUsers
		}
    #---End User Search Function
    #---Create Company Location Function
		Function NewLocation{
            Write-Host ""
            Write-Host ""
            $newCompanyName = Read-Host "Enter The Company Name"
            Write-Host ""
            Write-Host ""
			Write-Host "Please Wait While Creating Company Location"
			Write-Host ""
            Write-Host ""
		#---Place Built Location List in a Varable for search
            $newCompanyLocSearch = LocationList
        #---Search For Existing Company
            try{
				$patternFound = select-string -pattern "$newCompanyName" -InputObject $newCompanyLocSearch
				if ($patternFound -ne $null){
					Write-Host "The Company Already Exists, You Must Update The Existing Company With The New User"
					Write-Host ""
					Write-Host ""
				}
			#---Create New Location Based on Company Name
				Else{
					try {
						Write-Host "The Company's Environment is being created"
                        Invoke-Pacli ADDLOCATION LOCATION=`"\Americas\Prospect Locations\$newCompanyName`"
                        Invoke-Pacli ADDGROUP GROUP=`"$newCompanyName`" LOCATION=`"\Americas\Prospect Locations\$newCompanyName`"
						Invoke-Pacli ADDSAFE SAFE=`"$newCompanyName`" SAFEOPTIONS="576"
                        Invoke-Pacli ADDSAFESHARE SAFE=`"$newCompanyName`" GWACCOUNT=`"HTTPGWGroup`"
                        Invoke-Pacli OPENSAFE SAFE=`"$newCompanyName`"
                        Invoke-Pacli ADDFOLDER SAFE=`"$newCompanyName`" FOLDER=`"root\From CyberArk`"
                        Invoke-Pacli ADDFOLDER SAFE=`"$newCompanyName`" FOLDER=`"root\From CyberArk\Licenses`"
                        Invoke-Pacli ADDFOLDER SAFE=`"$newCompanyName`" FOLDER=`"root\From CyberArk\Licenses\POC Licenses `& Files`"
                        Invoke-Pacli ADDFOLDER SAFE=`"$newCompanyName`" FOLDER=`"root\From CyberArk\Licenses\DNA`"
						Invoke-Pacli ADDFOLDER SAFE=`"$newCompanyName`" FOLDER=`"root\From $newCompanyName`"
                        Invoke-Pacli ADDOWNER OWNER=`"$newCompanyName`" SAFE=`"$newCompanyName`" RETRIEVE="YES" STORE="YES"
                        Invoke-Pacli ADDOWNER OWNER=`"Cyber-Ark - Admin`" SAFE=`"$newCompanyName`" RETRIEVE="YES" STORE="YES" DELETE="YES" ADMINISTER="YES" SUPERVISE="YES" BACKUP="YES" MANAGEOWNERS="YES" ACCESSNOCONFIRMATION="YES" VALIDATESAFECONTENT="YES" LIST="YES" USEPASSWORD="YES" UPDATEOBJECTPROPERTIES="YES" CREATEFOLDER="YES" DELETEFOLDER="YES" MOVEFROM="YES" MOVEINTO="YES" VIEWAUDIT="YES" VIEWPERMISSIONS="YES" EVENTSLIST="YES" CREATEOBJECT="YES" RENAMEOBJECT="YES"
                        Invoke-Pacli DELETEOWNER OWNER=`"$usrName`" SAFE=`"$newCompanyName`"
					} 
					catch {
						$error = $_.Exception.Message
						Write-Host "ERROR MESSAGE: $error"
					}
					finally {
					Write-Host "Done!!"
					}
				}
			}
			catch{
			write-warning "Something was wrong with the company name provided"
			}
		#---End Create New Location Based on Company Name
        }
	#---End Create Company Location Function
    #---Create User Function
		Function NewUser{
			if($newCompanyLocSearch -ne $null){
				try{
				$newUsrName = Read-Host "Enter New Username (Users Email Address)"
        #---Generate a random password
        #---Usage: random-password <length>
				Function random-password ($length=15){
					$punc = 46..46
					$digits = 48..57
					$letters = 65..90 + 97..122
					$newPasswd = get-random -count $length `
					-input ($punc + $digits + $letters) |
					% -begin { $aa = $null } `
					-process {$aa += [char]$_} `
					-end {$aa}
				}                
        #---End Random Password Generation
				$newUsrPasswd = random-password
        #---Write New User Information to Log
				"Username:$newUsrName"| Out-File $PSScriptRoot\Logs\New_User$newCompanyName.log
				"Password:$newUsrPasswd"| Out-File $PSScriptRoot\Logs\New_User$newComanyName.log -append
		#--End Write New User Information to Log
				Write-Host = "The New User is being created"
                Set-Content .\ADDUserBat.bat "@echo off`n$pacliPath ADDUSER VAULT=""Vault"" USER=""$usrName"" DESTUSER=""$newUsrName"" PASSWORD=""$newUsrPasswd"""
                & .\ADDUserBat.bat
				}
				catch{
					$error = $_.Exception.Message2
                    Write-Host "ERROR MESSAGE: $error"
				}
				finally{
					rm ADDUserBat.bat
				}
			
			Else{
			Write-Host "You Must Create The Company Location First"
			}
			}
		}
	#---Create User Function
#---Update Vault Operation Functions
    #---Update Existing Company
    
	
	#---End Update Existing Company
    #---Update Existing User
    #---End Update Existing User
    #---Provision Users to CyberArk Software
    #---End Software Provision
    #---Provision Users to CyberArk Documentation
    #---End Documentation Provision
#---User Interaction Functions
	#---Search Vault Locations	
		Function SearchLocation{
            Write-Host ""
            Write-Host ""
            $searchCompanyName = Read-Host "Enter The Company Name"
            Write-Host ""
            Write-Host ""
        #---Place Built Location List in a Varable for search
            $CompanyLocSearch = LocationList
        #---Search For Existing Company
            $patternFound = select-string -pattern "$searchCompanyName" -InputObject $CompanyLocSearch
            if ($patternFound -ne $null){
				Write-Host "The Company Already Exists, Use The Update Support Vault Option to Update The Existing Company With The New User"
				Write-Host ""
				Write-Host ""
				return
            }                        
        }
	#---End Search Vault Locations
	#---Search Vault Users
	Function SearchUsers{
            Write-Host ""
            Write-Host ""
            $searchUserName = Read-Host "Enter The User Name"
            Write-Host ""
            Write-Host ""
        #---Place Built User List in a Varable for search
            $usrSearch = UserList
        #---Search For Existing Company
            $patternFound = select-string -pattern "$searchUserName" -InputObject $usrSearch
            if ($patternFound -ne $null){
				Write-Host "The User Already Exists, Use The Update Support Vault Option to Update The Existing User"
				Write-Host ""
				Write-Host ""
				return
            }                        
        }
	#---End Search Vault Users
	#---User Main Menu
		function MainMenu{
			param ([string]$Title = 'Support Vault Functions')
			Write-Host "=========================== $Title ==========================="
			Write-Host "To Create a New Support Vault Access Select Menu Items In Order"
			Write-Host "1: Press '1' to Search for Existing Company"
			Write-Host "2: Press '2' to Search for Existing User"
			Write-Host "3: Press '3' to Create Environment for Company"
			Write-Host "4: Press '4' to Create New User"
			Write-Host "U: Press 'u' to Update Support Vault"
			Write-Host "Q: Press 'Q' To quit and Logoff."
		}
	#---End Main Menu
		#---Menu Function Loop
            do{
                MainMenu
                $input = Read-Host "Please make a selection"
                switch ($input){
                #---Search Locations To Insure that the Company is not already created    
                    '1'{
						CompanySearch
                    }
                #---End Seach Locations
                #---Search Users To Insure that the User is not already created
                    '2'{
						SearchUsers
                    }
                #---End Search Users
                #---Build Location
                    '3'{
					NewLocation
                    }
                #---End Build Location
                #---Create New User
                    '4'{
					NewUser
                    }
                #---End Create User
                #---Support Vault Update Menu
                    'u'{
                    }
                #---End Support Vault Update Menu
                #---Quit and Logoff
                    'q'{
                    }
                }
                pause
            }
            until ($input -eq 'q')
		#---End Menu Loop
	#---Update Menu
		function UpdateMenu{
			param ([string]$Title = 'Support Vault Update Menu')
			Write-Host "=========================== $Title ==========================="
			Write-Host "1: Press '1' to Update Existing Company"
			Write-Host "2: Press '2' to Update Existing User"
			Write-Host "3: Press '3' to Grant Provision Users to CyberArk Software"
			Write-Host "4: Press '4' to Provision Users to CyberArk Documentation"
			Write-Host "m: Press 'm' to Return to the Main Menu."
			Write-Host "q: Press 'q' to Quit and Logoff"
		}
	#---End Update Menu
		#---Update Menu Function Loop
            do{
                UpdateMenu
                $input = Read-Host "Please make a selection"
                switch ($input){
                #---Update Existing Company    
                    '1'{
                    }
                #---End Update Existing Company
                #---Update Existing User
                    '2'{
                    }
                #---End Update Existing User
                #---Provision Users to CyberArk Software
                    '3'{
                    }
                #---End Provision Users to CyberArk Software
                #---Provision Users to CyberArk Documentation
                    '4'{
                    }
                #---End Provision Users to CyberArk Documentation
                #---Return to the Main Menu
                    'm'{
                    }
                #---End Return to the Main Menu
                #---Quit and Logoff
                    'q'{
                    }
                #---End Quit and Logoff        
                }
            pause
            }
            until ($input -eq 'm' -or $input -eq 'q')
		#---End Update Menu Loop