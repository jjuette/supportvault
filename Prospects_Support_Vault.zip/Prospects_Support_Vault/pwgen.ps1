﻿# Generate a random password
# Usage: random-password <length>
Function random-password ($length = 15)
{
        $punc = 46..46
        $digits = 48..57
        $letters = 65..90 + 97..122
        $ascii=$NULL;For ($a=33;$a –le 126;$a++) {$ascii+=,[char][byte]$a }

        # Thanks to
        # https://blogs.technet.com/b/heyscriptingguy/archive/2012/01/07/use-pow
        $password = get-random -count $length `
                -input ($punc + $digits + $letters + $ascii) |
                        % -begin { $aa = $null } `
                        -process {$aa += [char]$_} `
                        -end {$aa}

        return "$password"
}
$newuserpasswd = random-password 

Write-Host "$newuserpasswd"
